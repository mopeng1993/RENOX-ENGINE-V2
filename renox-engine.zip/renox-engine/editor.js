const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');
const path = require('path');
const fs = require('fs');
const { loadStyle } = require('./styles');

// Use bundled ffmpeg binary
ffmpeg.setFfmpegPath(ffmpegStatic);

const TARGET_DURATION = 15;   // seconds
const TARGET_FPS = 30;
const TARGET_W = 1080;
const TARGET_H = 1920;        // 9:16

/**
 * Main edit pipeline
 * @param {string} inputPath
 * @param {string} outputPath
 * @param {string} styleName
 * @returns {Promise<{duration: number}>}
 */
async function editVideo(inputPath, outputPath, styleName = 'sigma') {
  const meta = await probeVideo(inputPath);
  console.log(`📹 Input: ${meta.width}x${meta.height} | ${meta.duration.toFixed(1)}s | ${meta.fps}fps`);

  const style = loadStyle(styleName);
  const isHorizontal = meta.width > meta.height;

  // Calculate trim: pick the most "interesting" segment (prefer middle thirds)
  const clipStart = calcClipStart(meta.duration, TARGET_DURATION);
  const clipDuration = Math.min(TARGET_DURATION, meta.duration);

  // Speed factor: if source < 15s, slow down slightly; if > 15s, speed up
  const rawSpeed = meta.duration / TARGET_DURATION;
  const speedFactor = clamp(rawSpeed, 0.8, 2.0);

  console.log(`🎬 Style: ${styleName} | Horizontal: ${isHorizontal} | Speed: ${speedFactor.toFixed(2)}x | Start: ${clipStart.toFixed(1)}s`);

  const filterComplex = buildFilterComplex({
    meta,
    isHorizontal,
    clipStart,
    clipDuration,
    speedFactor,
    style,
    targetW: TARGET_W,
    targetH: TARGET_H,
    targetFps: TARGET_FPS,
  });

  await runFFmpeg(inputPath, outputPath, clipStart, clipDuration, filterComplex, speedFactor);

  const outMeta = await probeVideo(outputPath);
  console.log(`✅ Output: ${outMeta.width}x${outMeta.height} | ${outMeta.duration.toFixed(1)}s`);

  return { duration: Math.round(outMeta.duration) };
}

/**
 * Build FFmpeg filtergraph
 */
function buildFilterComplex({ meta, isHorizontal, clipStart, clipDuration, speedFactor, style, targetW, targetH, targetFps }) {
  const filters = [];

  if (isHorizontal) {
    // === HORIZONTAL → VERTICAL with blurred background ===

    // Scale background to fill 9:16, blur heavily
    filters.push(`[0:v]scale=${targetW}:${targetH}:force_original_aspect_ratio=increase,crop=${targetW}:${targetH},gblur=sigma=30,setsar=1[bg]`);

    // Scale foreground to fit within 9:16 with padding (subject preserved)
    const fgH = Math.round(targetH * 0.72); // foreground takes 72% height
    const fgW = Math.round(fgH * (meta.width / meta.height));
    const fgWEven = fgW % 2 === 0 ? fgW : fgW - 1;
    const fgHEven = fgH % 2 === 0 ? fgH : fgH - 1;
    const fgX = Math.round((targetW - fgWEven) / 2);
    const fgY = Math.round((targetH - fgHEven) / 2);

    filters.push(`[0:v]scale=${fgWEven}:${fgHEven},setsar=1[fg]`);

    // Overlay foreground centered on blurred background
    filters.push(`[bg][fg]overlay=${fgX}:${fgY}[composed]`);

    // Apply color grade from style
    filters.push(`[composed]${style.colorFilter}[graded]`);

    // Speed ramp + FPS
    filters.push(`[graded]setpts=${(1 / speedFactor).toFixed(4)}*PTS,fps=${targetFps}[out]`);
  } else {
    // === VERTICAL / PORTRAIT → scale/crop to exact 9:16 ===
    filters.push(`[0:v]scale=${targetW}:${targetH}:force_original_aspect_ratio=increase,crop=${targetW}:${targetH},setsar=1[scaled]`);
    filters.push(`[scaled]${style.colorFilter}[graded]`);
    filters.push(`[graded]setpts=${(1 / speedFactor).toFixed(4)}*PTS,fps=${targetFps}[out]`);
  }

  return filters.join(';');
}

/**
 * Run FFmpeg with built filtergraph
 */
function runFFmpeg(inputPath, outputPath, clipStart, clipDuration, filterComplex, speedFactor) {
  return new Promise((resolve, reject) => {
    const audioSpeed = clamp(speedFactor, 0.5, 2.0); // atempo range limit

    let cmd = ffmpeg(inputPath)
      .seekInput(clipStart)
      .duration(clipDuration / speedFactor + 0.5)  // give a bit of buffer
      .complexFilter(filterComplex, 'out')
      .outputOptions([
        '-map', '[out]',
        '-c:v', 'libx264',
        '-preset', 'veryfast',   // fast encode for Render Free CPU
        '-crf', '23',
        '-profile:v', 'baseline', // max compatibility
        '-level', '3.1',
        '-movflags', '+faststart', // web streaming
        '-pix_fmt', 'yuv420p',
        '-t', String(TARGET_DURATION),
      ]);

    // Handle audio (speed ramp audio too)
    if (audioSpeed !== 1.0) {
      cmd = cmd
        .outputOptions(['-map', '0:a?'])
        .audioFilters(`atempo=${audioSpeed.toFixed(4)}`)
        .audioCodec('aac')
        .audioBitrate('128k');
    } else {
      cmd = cmd
        .outputOptions(['-map', '0:a?'])
        .audioCodec('aac')
        .audioBitrate('128k');
    }

    cmd
      .output(outputPath)
      .on('start', (cmdLine) => console.log('🎬 FFmpeg:', cmdLine.substring(0, 120) + '...'))
      .on('progress', (p) => {
        if (p.percent) process.stdout.write(`\r⚙️  Encoding: ${Math.round(p.percent)}%`);
      })
      .on('end', () => { process.stdout.write('\n'); resolve(); })
      .on('error', (err) => { process.stdout.write('\n'); reject(new Error(`FFmpeg error: ${err.message}`)); })
      .run();
  });
}

/**
 * Probe video metadata
 */
function probeVideo(filePath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) return reject(new Error(`Probe failed: ${err.message}`));
      const vs = data.streams.find(s => s.codec_type === 'video');
      if (!vs) return reject(new Error('No video stream found'));

      const fpsRaw = vs.r_frame_rate || vs.avg_frame_rate || '30/1';
      const [n, d] = fpsRaw.split('/').map(Number);
      const fps = d ? n / d : 30;

      resolve({
        width: vs.width,
        height: vs.height,
        duration: parseFloat(data.format.duration) || 0,
        fps: Math.round(fps),
        hasAudio: data.streams.some(s => s.codec_type === 'audio'),
      });
    });
  });
}

/**
 * Pick clip start: prefer the middle third for "action" content
 */
function calcClipStart(totalDuration, clipLen) {
  if (totalDuration <= clipLen) return 0;
  // Prefer starting at 30% in (skip intros)
  const preferredStart = totalDuration * 0.30;
  const maxStart = totalDuration - clipLen;
  return Math.min(preferredStart, maxStart);
}

function clamp(val, min, max) {
  return Math.min(Math.max(val, min), max);
}

module.exports = { editVideo };
