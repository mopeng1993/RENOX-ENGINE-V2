/**
 * SIGMA — Bold, punchy, high-contrast TikTok style
 * High saturation, slight blue shadow lift, crushed blacks
 */
module.exports = {
  name: 'sigma',
  description: 'Bold & punchy — high contrast, saturated, TikTok energy',

  // FFmpeg color filter chain (applied as part of filtergraph)
  // eq: contrast, brightness, saturation, gamma
  // curves: crush blacks, boost highlights
  colorFilter: [
    'eq=contrast=1.20:brightness=0.02:saturation=1.35:gamma=0.95',
    'curves=r=\'0/0 0.08/0.04 0.5/0.52 1/1\':g=\'0/0 0.5/0.5 1/1\':b=\'0/0.03 0.5/0.5 1/1\'',
    'unsharp=3:3:0.8:3:3:0',       // slight sharpening
  ].join(','),

  // Speed ramp profile (multiplier applied per segment — for future advanced ramping)
  speedProfile: {
    type: 'linear',
    factor: 1.0,
  },
};
