/**
 * ANIME — High contrast, vivid saturation, cool tone
 * Crushed blacks, punchy colors, slight blue cast
 */
module.exports = {
  name: 'anime',
  description: 'Anime style — vivid colors, high contrast, cool-toned',

  colorFilter: [
    'eq=contrast=1.30:brightness=-0.02:saturation=1.60:gamma=0.90',
    // Cool shadows, vivid highlights
    'curves=r=\'0/0 0.2/0.18 0.8/0.83 1/1\':g=\'0/0 0.5/0.50 1/1\':b=\'0/0.04 0.3/0.34 0.8/0.82 1/1\'',
    'unsharp=3:3:1.2:3:3:0',       // strong sharpening
  ].join(','),

  speedProfile: {
    type: 'snap',
    factor: 1.1,
  },
};
