const sigma = require('./sigma');
const cinematic = require('./cinematic');
const emotional = require('./emotional');
const anime = require('./anime');

const STYLES = { sigma, cinematic, emotional, anime };

function loadStyle(name) {
  const style = STYLES[name?.toLowerCase()];
  if (!style) {
    console.warn(`⚠️ Unknown style "${name}", falling back to sigma`);
    return STYLES.sigma;
  }
  return style;
}

module.exports = { loadStyle, STYLES };
