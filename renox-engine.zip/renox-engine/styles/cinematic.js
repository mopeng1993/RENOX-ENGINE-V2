/**
 * CINEMATIC — Film-grade look, teal/orange LUT simulation
 * Lifted blacks, teal shadows, warm highlights
 */
module.exports = {
  name: 'cinematic',
  description: 'Cinematic grade — teal shadows, warm highlights, film look',

  colorFilter: [
    'eq=contrast=1.10:brightness=-0.01:saturation=0.90:gamma=1.05',
    // Teal shadows, orange highlights (classic film look via curves)
    'curves=r=\'0/0.04 0.3/0.32 0.7/0.72 1/0.97\':g=\'0/0.01 0.5/0.49 1/0.98\':b=\'0/0.06 0.3/0.34 0.7/0.68 1/0.95\'',
    'unsharp=5:5:0.4:5:5:0',       // soft sharpening
    'hue=s=0.85',
  ].join(','),

  speedProfile: {
    type: 'ease',
    factor: 1.0,
  },
};
