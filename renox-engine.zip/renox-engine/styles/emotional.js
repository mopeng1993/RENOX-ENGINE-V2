/**
 * EMOTIONAL — Soft, warm, desaturated highlight style
 * Pastel tones, lifted shadows, creamy feel
 */
module.exports = {
  name: 'emotional',
  description: 'Soft & warm — pastel tones, lifted shadows, dreamy',

  colorFilter: [
    'eq=contrast=0.95:brightness=0.04:saturation=0.80:gamma=1.08',
    // Warm lift, soft highlights
    'curves=r=\'0/0.06 0.5/0.55 1/1.0\':g=\'0/0.04 0.5/0.51 1/0.98\':b=\'0/0.02 0.5/0.46 1/0.92\'',
    'gblur=sigma=0.4',              // very subtle softening
  ].join(','),

  speedProfile: {
    type: 'slow',
    factor: 0.9,
  },
};
