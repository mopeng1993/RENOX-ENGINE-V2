# 🎬 RENOX ENGINE

> AI Video Editing Engine for Telegram — auto-converts any video into a TikTok/Reels/Shorts-ready 9:16 vertical short.

---

## ✨ Features

- **Auto-orientation detection** — Horizontal videos get a blurred background (not center-cropped)
- **Subject preservation** — Foreground overlaid centered on blurred background
- **15-second output** — Auto-trimmed from the most interesting segment
- **Speed ramp** — Intelligent speed adjustment based on source length
- **9:16 · 30fps** — Optimized for TikTok, Instagram Reels, YouTube Shorts
- **4 styles** — sigma, cinematic, emotional, anime
- **Handles up to 80MB / 3 minutes**

---

## 📁 Project Structure

```
renox-engine/
├── bot.js              # Telegram bot, download, send
├── editor.js           # FFmpeg pipeline (core)
├── styles/
│   ├── index.js        # Style loader
│   ├── sigma.js        # Bold & punchy
│   ├── cinematic.js    # Film grade
│   ├── emotional.js    # Soft & warm
│   └── anime.js        # High contrast
├── downloads/          # Temp input files (auto-cleaned)
├── output/             # Temp output files (auto-cleaned)
├── render.yaml         # Render deployment config
├── .github/workflows/
│   └── deploy.yml      # GitHub Actions CI/CD
└── .env.example        # Environment variables template
```

---

## 🚀 Quick Start

### 1. Create a Telegram Bot

1. Message [@BotFather](https://t.me/BotFather) on Telegram
2. Send `/newbot` and follow the prompts
3. Copy your **bot token**

### 2. Local Development

```bash
git clone https://github.com/YOUR_USERNAME/renox-engine.git
cd renox-engine
npm install

# Create .env
echo "TELEGRAM_BOT_TOKEN=your_token_here" > .env

# Start bot
npm start
```

> **Note:** `ffmpeg-static` bundles FFmpeg automatically — no manual install needed.

### 3. Deploy to Render (Free)

#### Option A: Render Dashboard (Recommended)

1. Push code to GitHub
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your GitHub repo
4. Settings:
   - **Environment:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `node bot.js`
   - **Plan:** Free
5. Add environment variable: `TELEGRAM_BOT_TOKEN` = your token
6. Click **Deploy**

#### Option B: render.yaml (Auto)

The included `render.yaml` handles all settings. Just connect the repo in Render dashboard — it reads the file automatically.

### 4. GitHub Auto-Deploy

1. In Render dashboard → your service → Settings → **Auto-Deploy: Yes**
2. Every push to `main` triggers a redeploy
3. GitHub Actions runs syntax validation before Render deploys

---

## 🎨 Styles

| Style | Look | Use case |
|-------|------|----------|
| `sigma` | High contrast, saturated, punchy | Gym, lifestyle, hype content |
| `cinematic` | Teal/orange, film grade | Travel, vlog, narrative |
| `emotional` | Soft, warm, pastel | Personal, emotional, storytelling |
| `anime` | Vivid, cool-toned, sharp | Gaming, cosplay, action |

**Set style via bot:**
```
/style cinematic
```

---

## 🤖 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome + instructions |
| `/style <name>` | Set editing style |
| `/help` | Help message |
| _(send video)_ | Auto-edit and return |

---

## ⚙️ How It Works

```
User sends video
      ↓
bot.js downloads via Telegram File API
      ↓
editor.js probes metadata (resolution, duration, fps)
      ↓
Detects orientation (horizontal vs vertical)
      ↓
Horizontal: blurred background + centered foreground overlay
Vertical:   scale/crop to 9:16
      ↓
Color grade applied (style filter)
      ↓
Speed ramp: source_duration / 15s (clamped 0.8x–2.0x)
      ↓
Trim: start at 30% of video (skip intros)
      ↓
FFmpeg encodes: H.264 baseline, 30fps, 9:16, faststart
      ↓
Bot sends result video
      ↓
Temp files deleted
```

---

## 🔧 Render Free Plan Notes

- **512MB RAM** — Sufficient for this stack (FFmpeg + Node)
- **Shared CPU** — Uses `veryfast` preset to keep encode times low
- **Spins down after 15min inactivity** — Keep-alive ping runs every 14 min
- **Ephemeral filesystem** — `downloads/` and `output/` are temp; files auto-deleted after each job
- **No persistent storage needed** — All processing is stateless

---

## 🛠 Extending

### Add a new style

Create `styles/mystyle.js`:
```js
module.exports = {
  name: 'mystyle',
  description: 'My custom look',
  colorFilter: 'eq=contrast=1.1:saturation=1.2',
  speedProfile: { type: 'linear', factor: 1.0 },
};
```

Register in `styles/index.js`:
```js
const mystyle = require('./mystyle');
const STYLES = { sigma, cinematic, emotional, anime, mystyle };
```

### Add text overlays

In `editor.js`, add to the filter chain:
```js
`drawtext=text='YOUR TEXT':fontcolor=white:fontsize=60:x=(w-text_w)/2:y=h-100`
```

---

## 📄 License

MIT
