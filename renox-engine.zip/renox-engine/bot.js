const TelegramBot = require('node-telegram-bot-api');
const path = require('path');
const fs = require('fs');
const https = require('https');
const http = require('http');
const { editVideo } = require('./editor');

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const MAX_FILE_SIZE = 80 * 1024 * 1024; // 80MB
const MAX_DURATION = 180; // 3 minutes

if (!TOKEN) {
  console.error('❌ TELEGRAM_BOT_TOKEN not set');
  process.exit(1);
}

// Use polling on Render Free (no webhook needed)
const bot = new TelegramBot(TOKEN, { polling: true });

// Ensure directories exist
['downloads', 'output'].forEach(dir => {
  const p = path.join(__dirname, dir);
  if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

console.log('🎬 RENOX ENGINE bot started');

// /start command
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId,
    `🎬 *RENOX ENGINE* — AI Video Editor\n\n` +
    `Send me a video and I'll auto-edit it into a 9:16 vertical short (15s, 30fps) optimized for TikTok / Reels / Shorts.\n\n` +
    `*Limits:* up to 80MB · up to 3 minutes\n\n` +
    `*Styles available:*\n` +
    `• /style sigma — Bold & punchy\n` +
    `• /style cinematic — Cinematic grade\n` +
    `• /style emotional — Soft & warm\n` +
    `• /style anime — High contrast anime\n\n` +
    `Default style: *sigma*\n\nJust send a video to get started! 🚀`,
    { parse_mode: 'Markdown' }
  );
});

// /style command
bot.onText(/\/style (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const style = match[1].trim().toLowerCase();
  const validStyles = ['sigma', 'cinematic', 'emotional', 'anime'];
  if (!validStyles.includes(style)) {
    return bot.sendMessage(chatId, `❌ Unknown style. Choose: ${validStyles.join(', ')}`);
  }
  userStyles[chatId] = style;
  bot.sendMessage(chatId, `✅ Style set to *${style}*. Now send a video!`, { parse_mode: 'Markdown' });
});

// /help command
bot.onText(/\/help/, (msg) => {
  bot.sendMessage(msg.chat.id,
    `*RENOX ENGINE Help*\n\n` +
    `1. Send any video (mp4, mov, avi)\n` +
    `2. Bot detects orientation and applies AI editing\n` +
    `3. Get back a 15s 9:16 vertical short\n\n` +
    `*Commands:*\n` +
    `/start — Welcome message\n` +
    `/style <name> — Set editing style\n` +
    `/help — This message`,
    { parse_mode: 'Markdown' }
  );
});

// Store per-user style preferences (in-memory, resets on restart)
const userStyles = {};

// Handle video messages
bot.on('video', async (msg) => {
  await handleVideoMessage(msg);
});

// Handle document (videos sent as files)
bot.on('document', async (msg) => {
  const doc = msg.document;
  const videoMimes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm', 'video/mpeg'];
  if (doc && videoMimes.includes(doc.mime_type)) {
    await handleVideoMessage(msg, true);
  }
});

async function handleVideoMessage(msg, isDocument = false) {
  const chatId = msg.chat.id;
  const fileObj = isDocument ? msg.document : msg.video;

  // Check file size
  if (fileObj.file_size && fileObj.file_size > MAX_FILE_SIZE) {
    return bot.sendMessage(chatId,
      `❌ File too large (${(fileObj.file_size / 1024 / 1024).toFixed(1)}MB). Max: 80MB.`
    );
  }

  // Check duration (only available on video type)
  if (!isDocument && msg.video.duration > MAX_DURATION) {
    return bot.sendMessage(chatId,
      `❌ Video too long (${msg.video.duration}s). Max: 3 minutes.`
    );
  }

  const style = userStyles[chatId] || 'sigma';
  const statusMsg = await bot.sendMessage(chatId,
    `⚙️ *RENOX ENGINE* processing...\nStyle: *${style}*\n\n⏳ Downloading video...`,
    { parse_mode: 'Markdown' }
  );

  const inputPath = path.join(__dirname, 'downloads', `${chatId}_${Date.now()}.mp4`);
  const outputPath = path.join(__dirname, 'output', `${chatId}_${Date.now()}_out.mp4`);

  try {
    // Step 1: Download
    await downloadTelegramFile(bot, fileObj.file_id, inputPath);
    await editStatus(bot, chatId, statusMsg.message_id,
      `⚙️ *RENOX ENGINE* processing...\nStyle: *${style}*\n\n🎞 Editing video...`
    );

    // Step 2: Edit
    const result = await editVideo(inputPath, outputPath, style);
    await editStatus(bot, chatId, statusMsg.message_id,
      `⚙️ *RENOX ENGINE* processing...\nStyle: *${style}*\n\n📤 Uploading result...`
    );

    // Step 3: Send result
    await bot.sendVideo(chatId, outputPath, {
      caption:
        `✅ *RENOX ENGINE* — Done!\n\n` +
        `🎬 Style: *${style}*\n` +
        `📐 Format: 9:16 vertical\n` +
        `⏱ Duration: ${result.duration}s\n` +
        `🎞 FPS: 30\n` +
        `📦 Optimized for TikTok / Reels / Shorts`,
      parse_mode: 'Markdown',
      supports_streaming: true,
    });

    await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
  } catch (err) {
    console.error('Processing error:', err);
    await editStatus(bot, chatId, statusMsg.message_id,
      `❌ Error processing video:\n\`${err.message}\`\n\nPlease try again.`
    );
  } finally {
    // Cleanup temp files
    [inputPath, outputPath].forEach(f => {
      if (fs.existsSync(f)) fs.unlink(f, () => {});
    });
  }
}

async function downloadTelegramFile(bot, fileId, destPath) {
  const fileInfo = await bot.getFile(fileId);
  const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${fileInfo.file_path}`;

  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const protocol = fileUrl.startsWith('https') ? https : http;
    protocol.get(fileUrl, (res) => {
      if (res.statusCode !== 200) {
        return reject(new Error(`Download failed: HTTP ${res.statusCode}`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(resolve));
      file.on('error', reject);
    }).on('error', reject);
  });
}

async function editStatus(bot, chatId, msgId, text) {
  try {
    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: 'Markdown',
    });
  } catch (_) {}
}

// Keep alive for Render Free (pings self)
if (process.env.RENDER_EXTERNAL_URL) {
  const url = process.env.RENDER_EXTERNAL_URL;
  setInterval(() => {
    https.get(url, () => {}).on('error', () => {});
  }, 14 * 60 * 1000); // every 14 minutes
}

// Health check HTTP server (required by Render)
const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'ok', engine: 'RENOX ENGINE', version: '1.0.0' }));
}).listen(PORT, () => {
  console.log(`🌐 Health server on port ${PORT}`);
});
